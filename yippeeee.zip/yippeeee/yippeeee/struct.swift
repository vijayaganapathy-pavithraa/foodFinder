//
//  struct.swift
//  yippeeee
//
//  Created by Vijayaganapathy Pavithraa on 4/5/24.
//

import Foundation
import SwiftUI

struct Restaurant: Identifiable, Hashable{
    var id = UUID()
    var category: Category
    var name: String
    var logo: UIImage
    var food: UIImage
    var rating: String
    var address: String
    var openingHours: String
    var menuLink: String
    var phoneNumber: String
    var priceRange: String
}

enum Category: CaseIterable{ //proper noun
    case drinks
    case indian
    case local
    case western
    case chinese
    var name: String {
        switch self {
        case .drinks:
            "Drinks"
        case .indian:
            "Indian"
        case .local:
            "Local"
        case .western:
            "Western"
        case .chinese:
            "Chinese"
        }
    }
}

//
//  ContentView.swift
//  yippeeee
//
//  Created by Vijayaganapathy Pavithraa on 27/4/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            List {
                ForEach (Category.allCases, id:\.hashValue) { category in
                    NavigationLink {
                        RestaurantListView(restaurant: category)
                    }label:{
                        Text(category.name)
                    }
                }
                
            }
            .navigationTitle("Cuisine")
        }
    }
}
#Preview {
    ContentView()
}
